﻿This module is intended to fix various problems for pogo spoofers, and safety net for rooted users even with the new 2020 google play update, the script will change as few intervals in your system as possible, it will ONLY change your device FP and xml permissions, and will clean your device for pogo spoofing.

IT WILL NOT GIVE YOU ANY CHEATS NOR METHOD FOR SPOOFING IT WILL ONLY FIX YOUR SAFETYNET ISSUES AND TWRP DETECT ISSUES BY NIANTIC YOU STILL NEED SMALI PATCHER AND A JOYSTICK to SPOOF

### V 0.1-alpha

Initial release

### V 0.2-beta

add xmls to make a better mimic of the pixel device and to enae arcore on pogo

more verbose installation

now support older than 7 devices, even on stock roms where props module from magisk repo doesn’t work, this script is as simple as can be, no known issues.

Pre installation removal of store cache, and twrp directory, to prevent pogo from detecting root.


### V 2.0.21
updated again for 2021, especially for samsung a** series.
Dedicated to Gili.

