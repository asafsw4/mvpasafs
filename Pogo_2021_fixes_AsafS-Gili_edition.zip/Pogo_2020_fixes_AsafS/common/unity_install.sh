# Clear Play Store data and remove twrp directory for pogo detectors.
if [ ! -d "$MODPATH" ]; then
  rm -rf /data/data/com.android.vending/cache
  rm -rf /data/twrp
fi
